
/*
 * Copyright 2022 Chair of EDA, Technical University of Munich
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	 http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "Factory.h"

#include "Channel.h"
#include "Backend.h"

#include "PerformanceEstimator.h"
#include "PerformanceModel.h"
#include "TracePrinter.h"
#include "Printer.h"

#include "CV32E40PXISAACV4_Channel.h"
#include "CV32E40PXISAACV4_PerformanceModel.h"
#include "CV32E40PXISAACV4_Printer.h"

#include "CV32E40PXISAACV8_PerformanceModel.h"
#include "CV32E40PXISAACV8_Channel.h"
#include "CV32E40PXISAACV8_Printer.h"

#include "CV32E40PXISAACV5_Channel.h"
#include "CV32E40PXISAACV5_PerformanceModel.h"
#include "CV32E40PXISAACV5_Printer.h"

#include "InstructionTrace_RV64IM_Zicsr_Printer.h"
#include "InstructionTrace_RV64IM_Zicsr_Channel.h"

#include "InstructionTrace_RV32IM_Zicsr_Printer.h"
#include "InstructionTrace_RV32IM_Zicsr_Channel.h"

#include "CV32E40PXISAACV11_Channel.h"
#include "CV32E40PXISAACV11_PerformanceModel.h"
#include "CV32E40PXISAACV11_Printer.h"

#include "InstructionTrace_XISAAC_Printer.h"
#include "InstructionTrace_XISAAC_Channel.h"

#include "CV32E40PXISAACV3_Printer.h"
#include "CV32E40PXISAACV3_PerformanceModel.h"
#include "CV32E40PXISAACV3_Channel.h"

#include "CV32E40PXISAACV14_Printer.h"
#include "CV32E40PXISAACV14_PerformanceModel.h"
#include "CV32E40PXISAACV14_Channel.h"

#include "CV32E40PXISAACV2_Printer.h"
#include "CV32E40PXISAACV2_Channel.h"
#include "CV32E40PXISAACV2_PerformanceModel.h"

#include "CV32E40PXISAACV6_Printer.h"
#include "CV32E40PXISAACV6_Channel.h"
#include "CV32E40PXISAACV6_PerformanceModel.h"

#include "CV32E40PXISAACV7_Channel.h"
#include "CV32E40PXISAACV7_Printer.h"
#include "CV32E40PXISAACV7_PerformanceModel.h"

#include "CV32E40PXISAACV13_PerformanceModel.h"
#include "CV32E40PXISAACV13_Printer.h"
#include "CV32E40PXISAACV13_Channel.h"

#include "InstructionTrace_RV64IMF_Zicsr_Printer.h"
#include "InstructionTrace_RV64IMF_Zicsr_Channel.h"

#include "CV32E40PXISAACV12_Channel.h"
#include "CV32E40PXISAACV12_Printer.h"
#include "CV32E40PXISAACV12_PerformanceModel.h"

#include "CVA6_Printer.h"
#include "CVA6_PerformanceModel.h"
#include "CVA6_Channel.h"

#include "CV32E40PXISAAC_Channel.h"
#include "CV32E40PXISAAC_PerformanceModel.h"
#include "CV32E40PXISAAC_Printer.h"

#include "CV32E40PXISAACV10_PerformanceModel.h"
#include "CV32E40PXISAACV10_Printer.h"
#include "CV32E40PXISAACV10_Channel.h"

#include "CV32E40PXISAACV0_PerformanceModel.h"
#include "CV32E40PXISAACV0_Channel.h"
#include "CV32E40PXISAACV0_Printer.h"

#include "AssemblyTrace_RV64_Channel.h"
#include "AssemblyTrace_RV64_Printer.h"

#include "CV32E40PXISAACV1_PerformanceModel.h"
#include "CV32E40PXISAACV1_Channel.h"
#include "CV32E40PXISAACV1_Printer.h"

#include "AssemblyTrace_RV32_Channel.h"
#include "AssemblyTrace_RV32_Printer.h"

#include "CVA6XISAAC_PerformanceModel.h"
#include "CVA6XISAAC_Channel.h"
#include "CVA6XISAAC_Printer.h"

#include "CV32E40P_Printer.h"
#include "CV32E40P_PerformanceModel.h"
#include "CV32E40P_Channel.h"

#include "CV32E40PXISAACV9_PerformanceModel.h"
#include "CV32E40PXISAACV9_Channel.h"
#include "CV32E40PXISAACV9_Printer.h"


namespace SwEvalBackends
{

int Factory::getVariantHandle(std::string varName_)
{
    	if(varName_ == "CV32E40PXISAACV4"){ return CV32E40PXISAACV4; }
	if(varName_ == "CV32E40PXISAACV8"){ return CV32E40PXISAACV8; }
	if(varName_ == "CV32E40PXISAACV5"){ return CV32E40PXISAACV5; }
	if(varName_ == "InstructionTrace_RV64IM_Zicsr"){ return InstructionTrace_RV64IM_Zicsr; }
	if(varName_ == "InstructionTrace_RV32IM_Zicsr"){ return InstructionTrace_RV32IM_Zicsr; }
	if(varName_ == "CV32E40PXISAACV11"){ return CV32E40PXISAACV11; }
	if(varName_ == "InstructionTrace_XISAAC"){ return InstructionTrace_XISAAC; }
	if(varName_ == "CV32E40PXISAACV3"){ return CV32E40PXISAACV3; }
	if(varName_ == "CV32E40PXISAACV14"){ return CV32E40PXISAACV14; }
	if(varName_ == "CV32E40PXISAACV2"){ return CV32E40PXISAACV2; }
	if(varName_ == "CV32E40PXISAACV6"){ return CV32E40PXISAACV6; }
	if(varName_ == "CV32E40PXISAACV7"){ return CV32E40PXISAACV7; }
	if(varName_ == "CV32E40PXISAACV13"){ return CV32E40PXISAACV13; }
	if(varName_ == "InstructionTrace_RV64IMF_Zicsr"){ return InstructionTrace_RV64IMF_Zicsr; }
	if(varName_ == "CV32E40PXISAACV12"){ return CV32E40PXISAACV12; }
	if(varName_ == "CVA6"){ return CVA6; }
	if(varName_ == "CV32E40PXISAAC"){ return CV32E40PXISAAC; }
	if(varName_ == "CV32E40PXISAACV10"){ return CV32E40PXISAACV10; }
	if(varName_ == "CV32E40PXISAACV0"){ return CV32E40PXISAACV0; }
	if(varName_ == "AssemblyTrace_RV64"){ return AssemblyTrace_RV64; }
	if(varName_ == "CV32E40PXISAACV1"){ return CV32E40PXISAACV1; }
	if(varName_ == "AssemblyTrace_RV32"){ return AssemblyTrace_RV32; }
	if(varName_ == "CVA6XISAAC"){ return CVA6XISAAC; }
	if(varName_ == "CV32E40P"){ return CV32E40P; }
	if(varName_ == "CV32E40PXISAACV9"){ return CV32E40PXISAACV9; }

    return -1;
}

Channel* Factory::getChannel(int var_)
{
  switch((var_t)var_)
  {
    	case CV32E40PXISAACV4: return new CV32E40PXISAACV4_Channel();
	case CV32E40PXISAACV8: return new CV32E40PXISAACV8_Channel();
	case CV32E40PXISAACV5: return new CV32E40PXISAACV5_Channel();
	case InstructionTrace_RV64IM_Zicsr: return new InstructionTrace_RV64IM_Zicsr_Channel();
	case InstructionTrace_RV32IM_Zicsr: return new InstructionTrace_RV32IM_Zicsr_Channel();
	case CV32E40PXISAACV11: return new CV32E40PXISAACV11_Channel();
	case InstructionTrace_XISAAC: return new InstructionTrace_XISAAC_Channel();
	case CV32E40PXISAACV3: return new CV32E40PXISAACV3_Channel();
	case CV32E40PXISAACV14: return new CV32E40PXISAACV14_Channel();
	case CV32E40PXISAACV2: return new CV32E40PXISAACV2_Channel();
	case CV32E40PXISAACV6: return new CV32E40PXISAACV6_Channel();
	case CV32E40PXISAACV7: return new CV32E40PXISAACV7_Channel();
	case CV32E40PXISAACV13: return new CV32E40PXISAACV13_Channel();
	case InstructionTrace_RV64IMF_Zicsr: return new InstructionTrace_RV64IMF_Zicsr_Channel();
	case CV32E40PXISAACV12: return new CV32E40PXISAACV12_Channel();
	case CVA6: return new CVA6_Channel();
	case CV32E40PXISAAC: return new CV32E40PXISAAC_Channel();
	case CV32E40PXISAACV10: return new CV32E40PXISAACV10_Channel();
	case CV32E40PXISAACV0: return new CV32E40PXISAACV0_Channel();
	case AssemblyTrace_RV64: return new AssemblyTrace_RV64_Channel();
	case CV32E40PXISAACV1: return new CV32E40PXISAACV1_Channel();
	case AssemblyTrace_RV32: return new AssemblyTrace_RV32_Channel();
	case CVA6XISAAC: return new CVA6XISAAC_Channel();
	case CV32E40P: return new CV32E40P_Channel();
	case CV32E40PXISAACV9: return new CV32E40PXISAACV9_Channel();

    default: return nullptr;
  }
}

Backend* Factory::getPerformanceEstimator(int var_)
{
  // Get performance model
  PerformanceModel* perfModel;
  switch((var_t)var_)
  {
    	case CV32E40PXISAACV4:
		perfModel = new CV32E40PXISAACV4::CV32E40PXISAACV4_PerformanceModel();
		break;
	case CV32E40PXISAACV8:
		perfModel = new CV32E40PXISAACV8::CV32E40PXISAACV8_PerformanceModel();
		break;
	case CV32E40PXISAACV5:
		perfModel = new CV32E40PXISAACV5::CV32E40PXISAACV5_PerformanceModel();
		break;
	case CV32E40PXISAACV11:
		perfModel = new CV32E40PXISAACV11::CV32E40PXISAACV11_PerformanceModel();
		break;
	case CV32E40PXISAACV3:
		perfModel = new CV32E40PXISAACV3::CV32E40PXISAACV3_PerformanceModel();
		break;
	case CV32E40PXISAACV14:
		perfModel = new CV32E40PXISAACV14::CV32E40PXISAACV14_PerformanceModel();
		break;
	case CV32E40PXISAACV2:
		perfModel = new CV32E40PXISAACV2::CV32E40PXISAACV2_PerformanceModel();
		break;
	case CV32E40PXISAACV6:
		perfModel = new CV32E40PXISAACV6::CV32E40PXISAACV6_PerformanceModel();
		break;
	case CV32E40PXISAACV7:
		perfModel = new CV32E40PXISAACV7::CV32E40PXISAACV7_PerformanceModel();
		break;
	case CV32E40PXISAACV13:
		perfModel = new CV32E40PXISAACV13::CV32E40PXISAACV13_PerformanceModel();
		break;
	case CV32E40PXISAACV12:
		perfModel = new CV32E40PXISAACV12::CV32E40PXISAACV12_PerformanceModel();
		break;
	case CVA6:
		perfModel = new CVA6::CVA6_PerformanceModel();
		break;
	case CV32E40PXISAAC:
		perfModel = new CV32E40PXISAAC::CV32E40PXISAAC_PerformanceModel();
		break;
	case CV32E40PXISAACV10:
		perfModel = new CV32E40PXISAACV10::CV32E40PXISAACV10_PerformanceModel();
		break;
	case CV32E40PXISAACV0:
		perfModel = new CV32E40PXISAACV0::CV32E40PXISAACV0_PerformanceModel();
		break;
	case CV32E40PXISAACV1:
		perfModel = new CV32E40PXISAACV1::CV32E40PXISAACV1_PerformanceModel();
		break;
	case CVA6XISAAC:
		perfModel = new CVA6XISAAC::CVA6XISAAC_PerformanceModel();
		break;
	case CV32E40P:
		perfModel = new CV32E40P::CV32E40P_PerformanceModel();
		break;
	case CV32E40PXISAACV9:
		perfModel = new CV32E40PXISAACV9::CV32E40PXISAACV9_PerformanceModel();
		break;

    default: perfModel = nullptr;
  }

  // Create PerformanceEstimator
  if(perfModel != nullptr)
  {
    return new PerformanceEstimator(perfModel);
  }
  else
  {
    return nullptr;
  }
}

Backend* Factory::getTracePrinter(int var_)
{
  // Get variant specific printer
  Printer* printer;
  switch((var_t)var_)
  {
    	case CV32E40PXISAACV4:
		printer = new CV32E40PXISAACV4_Printer();
		break;
	case CV32E40PXISAACV8:
		printer = new CV32E40PXISAACV8_Printer();
		break;
	case CV32E40PXISAACV5:
		printer = new CV32E40PXISAACV5_Printer();
		break;
	case InstructionTrace_RV64IM_Zicsr:
		printer = new InstructionTrace_RV64IM_Zicsr_Printer();
		break;
	case InstructionTrace_RV32IM_Zicsr:
		printer = new InstructionTrace_RV32IM_Zicsr_Printer();
		break;
	case CV32E40PXISAACV11:
		printer = new CV32E40PXISAACV11_Printer();
		break;
	case InstructionTrace_XISAAC:
		printer = new InstructionTrace_XISAAC_Printer();
		break;
	case CV32E40PXISAACV3:
		printer = new CV32E40PXISAACV3_Printer();
		break;
	case CV32E40PXISAACV14:
		printer = new CV32E40PXISAACV14_Printer();
		break;
	case CV32E40PXISAACV2:
		printer = new CV32E40PXISAACV2_Printer();
		break;
	case CV32E40PXISAACV6:
		printer = new CV32E40PXISAACV6_Printer();
		break;
	case CV32E40PXISAACV7:
		printer = new CV32E40PXISAACV7_Printer();
		break;
	case CV32E40PXISAACV13:
		printer = new CV32E40PXISAACV13_Printer();
		break;
	case InstructionTrace_RV64IMF_Zicsr:
		printer = new InstructionTrace_RV64IMF_Zicsr_Printer();
		break;
	case CV32E40PXISAACV12:
		printer = new CV32E40PXISAACV12_Printer();
		break;
	case CVA6:
		printer = new CVA6_Printer();
		break;
	case CV32E40PXISAAC:
		printer = new CV32E40PXISAAC_Printer();
		break;
	case CV32E40PXISAACV10:
		printer = new CV32E40PXISAACV10_Printer();
		break;
	case CV32E40PXISAACV0:
		printer = new CV32E40PXISAACV0_Printer();
		break;
	case AssemblyTrace_RV64:
		printer = new AssemblyTrace_RV64_Printer();
		break;
	case CV32E40PXISAACV1:
		printer = new CV32E40PXISAACV1_Printer();
		break;
	case AssemblyTrace_RV32:
		printer = new AssemblyTrace_RV32_Printer();
		break;
	case CVA6XISAAC:
		printer = new CVA6XISAAC_Printer();
		break;
	case CV32E40P:
		printer = new CV32E40P_Printer();
		break;
	case CV32E40PXISAACV9:
		printer = new CV32E40PXISAACV9_Printer();
		break;

    default: printer = nullptr;
  }

  // Create TracePrinter
  if(printer != nullptr)
  {
    return new TracePrinter(printer);
  }
  else
  {
    return nullptr;
  }
}

} // namespace SwEvalBackends
