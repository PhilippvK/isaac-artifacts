
/*
 * Copyright 2022 Chair of EDA, Technical University of Munich
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	 http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "Factory.h"

#include "Channel.h"
#include "Backend.h"

#include "PerformanceEstimator.h"
#include "PerformanceModel.h"
#include "TracePrinter.h"
#include "Printer.h"

#include "CV32E40PXISAACV4_Channel.h"
#include "CV32E40PXISAACV4_PerformanceModel.h"
#include "CV32E40PXISAACV4_Printer.h"

#include "CV32E40PXISAACV34_Channel.h"
#include "CV32E40PXISAACV34_Printer.h"
#include "CV32E40PXISAACV34_PerformanceModel.h"

#include "CV32E40PXISAACV26_Printer.h"
#include "CV32E40PXISAACV26_PerformanceModel.h"
#include "CV32E40PXISAACV26_Channel.h"

#include "CV32E40PXISAACV8_PerformanceModel.h"
#include "CV32E40PXISAACV8_Channel.h"
#include "CV32E40PXISAACV8_Printer.h"

#include "CV32E40PXISAACV23_Printer.h"
#include "CV32E40PXISAACV23_Channel.h"
#include "CV32E40PXISAACV23_PerformanceModel.h"

#include "CV32E40PXISAACV5_Channel.h"
#include "CV32E40PXISAACV5_PerformanceModel.h"
#include "CV32E40PXISAACV5_Printer.h"

#include "InstructionTrace_RV64IM_Zicsr_Printer.h"
#include "InstructionTrace_RV64IM_Zicsr_Channel.h"

#include "CV32E40PXISAACV39_Channel.h"
#include "CV32E40PXISAACV39_Printer.h"
#include "CV32E40PXISAACV39_PerformanceModel.h"

#include "InstructionTrace_RV32IM_Zicsr_Printer.h"
#include "InstructionTrace_RV32IM_Zicsr_Channel.h"

#include "CV32E40PXISAACV35_PerformanceModel.h"
#include "CV32E40PXISAACV35_Printer.h"
#include "CV32E40PXISAACV35_Channel.h"

#include "CV32E40PXISAACV24_PerformanceModel.h"
#include "CV32E40PXISAACV24_Printer.h"
#include "CV32E40PXISAACV24_Channel.h"

#include "CV32E40PXISAACV20_Printer.h"
#include "CV32E40PXISAACV20_Channel.h"
#include "CV32E40PXISAACV20_PerformanceModel.h"

#include "CV32E40PXISAACV19_Printer.h"
#include "CV32E40PXISAACV19_Channel.h"
#include "CV32E40PXISAACV19_PerformanceModel.h"

#include "CV32E40PXISAACV18_Printer.h"
#include "CV32E40PXISAACV18_PerformanceModel.h"
#include "CV32E40PXISAACV18_Channel.h"

#include "CV32E40PXISAACV37_Channel.h"
#include "CV32E40PXISAACV37_PerformanceModel.h"
#include "CV32E40PXISAACV37_Printer.h"

#include "CV32E40PXISAACV31_Printer.h"
#include "CV32E40PXISAACV31_Channel.h"
#include "CV32E40PXISAACV31_PerformanceModel.h"

#include "CV32E40PXISAACV11_Channel.h"
#include "CV32E40PXISAACV11_PerformanceModel.h"
#include "CV32E40PXISAACV11_Printer.h"

#include "InstructionTrace_XISAAC_Printer.h"
#include "InstructionTrace_XISAAC_Channel.h"

#include "CV32E40PXISAACV33_Printer.h"
#include "CV32E40PXISAACV33_PerformanceModel.h"
#include "CV32E40PXISAACV33_Channel.h"

#include "CV32E40PXISAACV38_Printer.h"
#include "CV32E40PXISAACV38_Channel.h"
#include "CV32E40PXISAACV38_PerformanceModel.h"

#include "CV32E40PXISAACV3_Printer.h"
#include "CV32E40PXISAACV3_PerformanceModel.h"
#include "CV32E40PXISAACV3_Channel.h"

#include "CV32E40PXISAACV14_Printer.h"
#include "CV32E40PXISAACV14_PerformanceModel.h"
#include "CV32E40PXISAACV14_Channel.h"

#include "CV32E40PXISAACV2_Printer.h"
#include "CV32E40PXISAACV2_Channel.h"
#include "CV32E40PXISAACV2_PerformanceModel.h"

#include "CV32E40PXISAACV43_PerformanceModel.h"
#include "CV32E40PXISAACV43_Printer.h"
#include "CV32E40PXISAACV43_Channel.h"

#include "CV32E40PXISAACV29_PerformanceModel.h"
#include "CV32E40PXISAACV29_Printer.h"
#include "CV32E40PXISAACV29_Channel.h"

#include "CV32E40PXISAACV6_Printer.h"
#include "CV32E40PXISAACV6_Channel.h"
#include "CV32E40PXISAACV6_PerformanceModel.h"

#include "CV32E40PXISAACV42_PerformanceModel.h"
#include "CV32E40PXISAACV42_Channel.h"
#include "CV32E40PXISAACV42_Printer.h"

#include "CV32E40PXISAACV7_Channel.h"
#include "CV32E40PXISAACV7_Printer.h"
#include "CV32E40PXISAACV7_PerformanceModel.h"

#include "CV32E40PXISAACV13_PerformanceModel.h"
#include "CV32E40PXISAACV13_Printer.h"
#include "CV32E40PXISAACV13_Channel.h"

#include "InstructionTrace_RV64IMF_Zicsr_Printer.h"
#include "InstructionTrace_RV64IMF_Zicsr_Channel.h"

#include "CV32E40PXISAACV41_Channel.h"
#include "CV32E40PXISAACV41_Printer.h"
#include "CV32E40PXISAACV41_PerformanceModel.h"

#include "CV32E40PXISAACV15_Printer.h"
#include "CV32E40PXISAACV15_PerformanceModel.h"
#include "CV32E40PXISAACV15_Channel.h"

#include "CV32E40PXISAACV25_PerformanceModel.h"
#include "CV32E40PXISAACV25_Printer.h"
#include "CV32E40PXISAACV25_Channel.h"

#include "CV32E40PXISAACV36_PerformanceModel.h"
#include "CV32E40PXISAACV36_Printer.h"
#include "CV32E40PXISAACV36_Channel.h"

#include "CV32E40PXISAACV12_Channel.h"
#include "CV32E40PXISAACV12_Printer.h"
#include "CV32E40PXISAACV12_PerformanceModel.h"

#include "CVA6_Printer.h"
#include "CVA6_PerformanceModel.h"
#include "CVA6_Channel.h"

#include "CV32E40PXISAACV28_Printer.h"
#include "CV32E40PXISAACV28_Channel.h"
#include "CV32E40PXISAACV28_PerformanceModel.h"

#include "CV32E40PXISAACV32_PerformanceModel.h"
#include "CV32E40PXISAACV32_Printer.h"
#include "CV32E40PXISAACV32_Channel.h"

#include "CV32E40PXISAAC_Channel.h"
#include "CV32E40PXISAAC_PerformanceModel.h"
#include "CV32E40PXISAAC_Printer.h"

#include "CV32E40PXISAACV10_PerformanceModel.h"
#include "CV32E40PXISAACV10_Printer.h"
#include "CV32E40PXISAACV10_Channel.h"

#include "CV32E40PXISAACV44_Printer.h"
#include "CV32E40PXISAACV44_Channel.h"
#include "CV32E40PXISAACV44_PerformanceModel.h"

#include "CV32E40PXISAACV0_PerformanceModel.h"
#include "CV32E40PXISAACV0_Channel.h"
#include "CV32E40PXISAACV0_Printer.h"

#include "CV32E40PXISAACV22_Printer.h"
#include "CV32E40PXISAACV22_Channel.h"
#include "CV32E40PXISAACV22_PerformanceModel.h"

#include "AssemblyTrace_RV64_Channel.h"
#include "AssemblyTrace_RV64_Printer.h"

#include "CV32E40PXISAACV17_PerformanceModel.h"
#include "CV32E40PXISAACV17_Channel.h"
#include "CV32E40PXISAACV17_Printer.h"

#include "CV32E40PXISAACV1_PerformanceModel.h"
#include "CV32E40PXISAACV1_Channel.h"
#include "CV32E40PXISAACV1_Printer.h"

#include "CV32E40PXISAACV21_PerformanceModel.h"
#include "CV32E40PXISAACV21_Printer.h"
#include "CV32E40PXISAACV21_Channel.h"

#include "AssemblyTrace_RV32_Channel.h"
#include "AssemblyTrace_RV32_Printer.h"

#include "CV32E40PXISAACV16_PerformanceModel.h"
#include "CV32E40PXISAACV16_Channel.h"
#include "CV32E40PXISAACV16_Printer.h"

#include "CVA6XISAAC_PerformanceModel.h"
#include "CVA6XISAAC_Channel.h"
#include "CVA6XISAAC_Printer.h"

#include "CV32E40P_Printer.h"
#include "CV32E40P_PerformanceModel.h"
#include "CV32E40P_Channel.h"

#include "CV32E40PXISAACV30_Printer.h"
#include "CV32E40PXISAACV30_Channel.h"
#include "CV32E40PXISAACV30_PerformanceModel.h"

#include "CV32E40PXISAACV40_Channel.h"
#include "CV32E40PXISAACV40_PerformanceModel.h"
#include "CV32E40PXISAACV40_Printer.h"

#include "CV32E40PXISAACV9_PerformanceModel.h"
#include "CV32E40PXISAACV9_Channel.h"
#include "CV32E40PXISAACV9_Printer.h"

#include "CV32E40PXISAACV27_Channel.h"
#include "CV32E40PXISAACV27_Printer.h"
#include "CV32E40PXISAACV27_PerformanceModel.h"


namespace SwEvalBackends
{

int Factory::getVariantHandle(std::string varName_)
{
    	if(varName_ == "CV32E40PXISAACV4"){ return CV32E40PXISAACV4; }
	if(varName_ == "CV32E40PXISAACV34"){ return CV32E40PXISAACV34; }
	if(varName_ == "CV32E40PXISAACV26"){ return CV32E40PXISAACV26; }
	if(varName_ == "CV32E40PXISAACV8"){ return CV32E40PXISAACV8; }
	if(varName_ == "CV32E40PXISAACV23"){ return CV32E40PXISAACV23; }
	if(varName_ == "CV32E40PXISAACV5"){ return CV32E40PXISAACV5; }
	if(varName_ == "InstructionTrace_RV64IM_Zicsr"){ return InstructionTrace_RV64IM_Zicsr; }
	if(varName_ == "CV32E40PXISAACV39"){ return CV32E40PXISAACV39; }
	if(varName_ == "InstructionTrace_RV32IM_Zicsr"){ return InstructionTrace_RV32IM_Zicsr; }
	if(varName_ == "CV32E40PXISAACV35"){ return CV32E40PXISAACV35; }
	if(varName_ == "CV32E40PXISAACV24"){ return CV32E40PXISAACV24; }
	if(varName_ == "CV32E40PXISAACV20"){ return CV32E40PXISAACV20; }
	if(varName_ == "CV32E40PXISAACV19"){ return CV32E40PXISAACV19; }
	if(varName_ == "CV32E40PXISAACV18"){ return CV32E40PXISAACV18; }
	if(varName_ == "CV32E40PXISAACV37"){ return CV32E40PXISAACV37; }
	if(varName_ == "CV32E40PXISAACV31"){ return CV32E40PXISAACV31; }
	if(varName_ == "CV32E40PXISAACV11"){ return CV32E40PXISAACV11; }
	if(varName_ == "InstructionTrace_XISAAC"){ return InstructionTrace_XISAAC; }
	if(varName_ == "CV32E40PXISAACV33"){ return CV32E40PXISAACV33; }
	if(varName_ == "CV32E40PXISAACV38"){ return CV32E40PXISAACV38; }
	if(varName_ == "CV32E40PXISAACV3"){ return CV32E40PXISAACV3; }
	if(varName_ == "CV32E40PXISAACV14"){ return CV32E40PXISAACV14; }
	if(varName_ == "CV32E40PXISAACV2"){ return CV32E40PXISAACV2; }
	if(varName_ == "CV32E40PXISAACV43"){ return CV32E40PXISAACV43; }
	if(varName_ == "CV32E40PXISAACV29"){ return CV32E40PXISAACV29; }
	if(varName_ == "CV32E40PXISAACV6"){ return CV32E40PXISAACV6; }
	if(varName_ == "CV32E40PXISAACV42"){ return CV32E40PXISAACV42; }
	if(varName_ == "CV32E40PXISAACV7"){ return CV32E40PXISAACV7; }
	if(varName_ == "CV32E40PXISAACV13"){ return CV32E40PXISAACV13; }
	if(varName_ == "InstructionTrace_RV64IMF_Zicsr"){ return InstructionTrace_RV64IMF_Zicsr; }
	if(varName_ == "CV32E40PXISAACV41"){ return CV32E40PXISAACV41; }
	if(varName_ == "CV32E40PXISAACV15"){ return CV32E40PXISAACV15; }
	if(varName_ == "CV32E40PXISAACV25"){ return CV32E40PXISAACV25; }
	if(varName_ == "CV32E40PXISAACV36"){ return CV32E40PXISAACV36; }
	if(varName_ == "CV32E40PXISAACV12"){ return CV32E40PXISAACV12; }
	if(varName_ == "CVA6"){ return CVA6; }
	if(varName_ == "CV32E40PXISAACV28"){ return CV32E40PXISAACV28; }
	if(varName_ == "CV32E40PXISAACV32"){ return CV32E40PXISAACV32; }
	if(varName_ == "CV32E40PXISAAC"){ return CV32E40PXISAAC; }
	if(varName_ == "CV32E40PXISAACV10"){ return CV32E40PXISAACV10; }
	if(varName_ == "CV32E40PXISAACV44"){ return CV32E40PXISAACV44; }
	if(varName_ == "CV32E40PXISAACV0"){ return CV32E40PXISAACV0; }
	if(varName_ == "CV32E40PXISAACV22"){ return CV32E40PXISAACV22; }
	if(varName_ == "AssemblyTrace_RV64"){ return AssemblyTrace_RV64; }
	if(varName_ == "CV32E40PXISAACV17"){ return CV32E40PXISAACV17; }
	if(varName_ == "CV32E40PXISAACV1"){ return CV32E40PXISAACV1; }
	if(varName_ == "CV32E40PXISAACV21"){ return CV32E40PXISAACV21; }
	if(varName_ == "AssemblyTrace_RV32"){ return AssemblyTrace_RV32; }
	if(varName_ == "CV32E40PXISAACV16"){ return CV32E40PXISAACV16; }
	if(varName_ == "CVA6XISAAC"){ return CVA6XISAAC; }
	if(varName_ == "CV32E40P"){ return CV32E40P; }
	if(varName_ == "CV32E40PXISAACV30"){ return CV32E40PXISAACV30; }
	if(varName_ == "CV32E40PXISAACV40"){ return CV32E40PXISAACV40; }
	if(varName_ == "CV32E40PXISAACV9"){ return CV32E40PXISAACV9; }
	if(varName_ == "CV32E40PXISAACV27"){ return CV32E40PXISAACV27; }

    return -1;
}

Channel* Factory::getChannel(int var_)
{
  switch((var_t)var_)
  {
    	case CV32E40PXISAACV4: return new CV32E40PXISAACV4_Channel();
	case CV32E40PXISAACV34: return new CV32E40PXISAACV34_Channel();
	case CV32E40PXISAACV26: return new CV32E40PXISAACV26_Channel();
	case CV32E40PXISAACV8: return new CV32E40PXISAACV8_Channel();
	case CV32E40PXISAACV23: return new CV32E40PXISAACV23_Channel();
	case CV32E40PXISAACV5: return new CV32E40PXISAACV5_Channel();
	case InstructionTrace_RV64IM_Zicsr: return new InstructionTrace_RV64IM_Zicsr_Channel();
	case CV32E40PXISAACV39: return new CV32E40PXISAACV39_Channel();
	case InstructionTrace_RV32IM_Zicsr: return new InstructionTrace_RV32IM_Zicsr_Channel();
	case CV32E40PXISAACV35: return new CV32E40PXISAACV35_Channel();
	case CV32E40PXISAACV24: return new CV32E40PXISAACV24_Channel();
	case CV32E40PXISAACV20: return new CV32E40PXISAACV20_Channel();
	case CV32E40PXISAACV19: return new CV32E40PXISAACV19_Channel();
	case CV32E40PXISAACV18: return new CV32E40PXISAACV18_Channel();
	case CV32E40PXISAACV37: return new CV32E40PXISAACV37_Channel();
	case CV32E40PXISAACV31: return new CV32E40PXISAACV31_Channel();
	case CV32E40PXISAACV11: return new CV32E40PXISAACV11_Channel();
	case InstructionTrace_XISAAC: return new InstructionTrace_XISAAC_Channel();
	case CV32E40PXISAACV33: return new CV32E40PXISAACV33_Channel();
	case CV32E40PXISAACV38: return new CV32E40PXISAACV38_Channel();
	case CV32E40PXISAACV3: return new CV32E40PXISAACV3_Channel();
	case CV32E40PXISAACV14: return new CV32E40PXISAACV14_Channel();
	case CV32E40PXISAACV2: return new CV32E40PXISAACV2_Channel();
	case CV32E40PXISAACV43: return new CV32E40PXISAACV43_Channel();
	case CV32E40PXISAACV29: return new CV32E40PXISAACV29_Channel();
	case CV32E40PXISAACV6: return new CV32E40PXISAACV6_Channel();
	case CV32E40PXISAACV42: return new CV32E40PXISAACV42_Channel();
	case CV32E40PXISAACV7: return new CV32E40PXISAACV7_Channel();
	case CV32E40PXISAACV13: return new CV32E40PXISAACV13_Channel();
	case InstructionTrace_RV64IMF_Zicsr: return new InstructionTrace_RV64IMF_Zicsr_Channel();
	case CV32E40PXISAACV41: return new CV32E40PXISAACV41_Channel();
	case CV32E40PXISAACV15: return new CV32E40PXISAACV15_Channel();
	case CV32E40PXISAACV25: return new CV32E40PXISAACV25_Channel();
	case CV32E40PXISAACV36: return new CV32E40PXISAACV36_Channel();
	case CV32E40PXISAACV12: return new CV32E40PXISAACV12_Channel();
	case CVA6: return new CVA6_Channel();
	case CV32E40PXISAACV28: return new CV32E40PXISAACV28_Channel();
	case CV32E40PXISAACV32: return new CV32E40PXISAACV32_Channel();
	case CV32E40PXISAAC: return new CV32E40PXISAAC_Channel();
	case CV32E40PXISAACV10: return new CV32E40PXISAACV10_Channel();
	case CV32E40PXISAACV44: return new CV32E40PXISAACV44_Channel();
	case CV32E40PXISAACV0: return new CV32E40PXISAACV0_Channel();
	case CV32E40PXISAACV22: return new CV32E40PXISAACV22_Channel();
	case AssemblyTrace_RV64: return new AssemblyTrace_RV64_Channel();
	case CV32E40PXISAACV17: return new CV32E40PXISAACV17_Channel();
	case CV32E40PXISAACV1: return new CV32E40PXISAACV1_Channel();
	case CV32E40PXISAACV21: return new CV32E40PXISAACV21_Channel();
	case AssemblyTrace_RV32: return new AssemblyTrace_RV32_Channel();
	case CV32E40PXISAACV16: return new CV32E40PXISAACV16_Channel();
	case CVA6XISAAC: return new CVA6XISAAC_Channel();
	case CV32E40P: return new CV32E40P_Channel();
	case CV32E40PXISAACV30: return new CV32E40PXISAACV30_Channel();
	case CV32E40PXISAACV40: return new CV32E40PXISAACV40_Channel();
	case CV32E40PXISAACV9: return new CV32E40PXISAACV9_Channel();
	case CV32E40PXISAACV27: return new CV32E40PXISAACV27_Channel();

    default: return nullptr;
  }
}

Backend* Factory::getPerformanceEstimator(int var_)
{
  // Get performance model
  PerformanceModel* perfModel;
  switch((var_t)var_)
  {
    	case CV32E40PXISAACV4:
		perfModel = new CV32E40PXISAACV4::CV32E40PXISAACV4_PerformanceModel();
		break;
	case CV32E40PXISAACV34:
		perfModel = new CV32E40PXISAACV34::CV32E40PXISAACV34_PerformanceModel();
		break;
	case CV32E40PXISAACV26:
		perfModel = new CV32E40PXISAACV26::CV32E40PXISAACV26_PerformanceModel();
		break;
	case CV32E40PXISAACV8:
		perfModel = new CV32E40PXISAACV8::CV32E40PXISAACV8_PerformanceModel();
		break;
	case CV32E40PXISAACV23:
		perfModel = new CV32E40PXISAACV23::CV32E40PXISAACV23_PerformanceModel();
		break;
	case CV32E40PXISAACV5:
		perfModel = new CV32E40PXISAACV5::CV32E40PXISAACV5_PerformanceModel();
		break;
	case CV32E40PXISAACV39:
		perfModel = new CV32E40PXISAACV39::CV32E40PXISAACV39_PerformanceModel();
		break;
	case CV32E40PXISAACV35:
		perfModel = new CV32E40PXISAACV35::CV32E40PXISAACV35_PerformanceModel();
		break;
	case CV32E40PXISAACV24:
		perfModel = new CV32E40PXISAACV24::CV32E40PXISAACV24_PerformanceModel();
		break;
	case CV32E40PXISAACV20:
		perfModel = new CV32E40PXISAACV20::CV32E40PXISAACV20_PerformanceModel();
		break;
	case CV32E40PXISAACV19:
		perfModel = new CV32E40PXISAACV19::CV32E40PXISAACV19_PerformanceModel();
		break;
	case CV32E40PXISAACV18:
		perfModel = new CV32E40PXISAACV18::CV32E40PXISAACV18_PerformanceModel();
		break;
	case CV32E40PXISAACV37:
		perfModel = new CV32E40PXISAACV37::CV32E40PXISAACV37_PerformanceModel();
		break;
	case CV32E40PXISAACV31:
		perfModel = new CV32E40PXISAACV31::CV32E40PXISAACV31_PerformanceModel();
		break;
	case CV32E40PXISAACV11:
		perfModel = new CV32E40PXISAACV11::CV32E40PXISAACV11_PerformanceModel();
		break;
	case CV32E40PXISAACV33:
		perfModel = new CV32E40PXISAACV33::CV32E40PXISAACV33_PerformanceModel();
		break;
	case CV32E40PXISAACV38:
		perfModel = new CV32E40PXISAACV38::CV32E40PXISAACV38_PerformanceModel();
		break;
	case CV32E40PXISAACV3:
		perfModel = new CV32E40PXISAACV3::CV32E40PXISAACV3_PerformanceModel();
		break;
	case CV32E40PXISAACV14:
		perfModel = new CV32E40PXISAACV14::CV32E40PXISAACV14_PerformanceModel();
		break;
	case CV32E40PXISAACV2:
		perfModel = new CV32E40PXISAACV2::CV32E40PXISAACV2_PerformanceModel();
		break;
	case CV32E40PXISAACV43:
		perfModel = new CV32E40PXISAACV43::CV32E40PXISAACV43_PerformanceModel();
		break;
	case CV32E40PXISAACV29:
		perfModel = new CV32E40PXISAACV29::CV32E40PXISAACV29_PerformanceModel();
		break;
	case CV32E40PXISAACV6:
		perfModel = new CV32E40PXISAACV6::CV32E40PXISAACV6_PerformanceModel();
		break;
	case CV32E40PXISAACV42:
		perfModel = new CV32E40PXISAACV42::CV32E40PXISAACV42_PerformanceModel();
		break;
	case CV32E40PXISAACV7:
		perfModel = new CV32E40PXISAACV7::CV32E40PXISAACV7_PerformanceModel();
		break;
	case CV32E40PXISAACV13:
		perfModel = new CV32E40PXISAACV13::CV32E40PXISAACV13_PerformanceModel();
		break;
	case CV32E40PXISAACV41:
		perfModel = new CV32E40PXISAACV41::CV32E40PXISAACV41_PerformanceModel();
		break;
	case CV32E40PXISAACV15:
		perfModel = new CV32E40PXISAACV15::CV32E40PXISAACV15_PerformanceModel();
		break;
	case CV32E40PXISAACV25:
		perfModel = new CV32E40PXISAACV25::CV32E40PXISAACV25_PerformanceModel();
		break;
	case CV32E40PXISAACV36:
		perfModel = new CV32E40PXISAACV36::CV32E40PXISAACV36_PerformanceModel();
		break;
	case CV32E40PXISAACV12:
		perfModel = new CV32E40PXISAACV12::CV32E40PXISAACV12_PerformanceModel();
		break;
	case CVA6:
		perfModel = new CVA6::CVA6_PerformanceModel();
		break;
	case CV32E40PXISAACV28:
		perfModel = new CV32E40PXISAACV28::CV32E40PXISAACV28_PerformanceModel();
		break;
	case CV32E40PXISAACV32:
		perfModel = new CV32E40PXISAACV32::CV32E40PXISAACV32_PerformanceModel();
		break;
	case CV32E40PXISAAC:
		perfModel = new CV32E40PXISAAC::CV32E40PXISAAC_PerformanceModel();
		break;
	case CV32E40PXISAACV10:
		perfModel = new CV32E40PXISAACV10::CV32E40PXISAACV10_PerformanceModel();
		break;
	case CV32E40PXISAACV44:
		perfModel = new CV32E40PXISAACV44::CV32E40PXISAACV44_PerformanceModel();
		break;
	case CV32E40PXISAACV0:
		perfModel = new CV32E40PXISAACV0::CV32E40PXISAACV0_PerformanceModel();
		break;
	case CV32E40PXISAACV22:
		perfModel = new CV32E40PXISAACV22::CV32E40PXISAACV22_PerformanceModel();
		break;
	case CV32E40PXISAACV17:
		perfModel = new CV32E40PXISAACV17::CV32E40PXISAACV17_PerformanceModel();
		break;
	case CV32E40PXISAACV1:
		perfModel = new CV32E40PXISAACV1::CV32E40PXISAACV1_PerformanceModel();
		break;
	case CV32E40PXISAACV21:
		perfModel = new CV32E40PXISAACV21::CV32E40PXISAACV21_PerformanceModel();
		break;
	case CV32E40PXISAACV16:
		perfModel = new CV32E40PXISAACV16::CV32E40PXISAACV16_PerformanceModel();
		break;
	case CVA6XISAAC:
		perfModel = new CVA6XISAAC::CVA6XISAAC_PerformanceModel();
		break;
	case CV32E40P:
		perfModel = new CV32E40P::CV32E40P_PerformanceModel();
		break;
	case CV32E40PXISAACV30:
		perfModel = new CV32E40PXISAACV30::CV32E40PXISAACV30_PerformanceModel();
		break;
	case CV32E40PXISAACV40:
		perfModel = new CV32E40PXISAACV40::CV32E40PXISAACV40_PerformanceModel();
		break;
	case CV32E40PXISAACV9:
		perfModel = new CV32E40PXISAACV9::CV32E40PXISAACV9_PerformanceModel();
		break;
	case CV32E40PXISAACV27:
		perfModel = new CV32E40PXISAACV27::CV32E40PXISAACV27_PerformanceModel();
		break;

    default: perfModel = nullptr;
  }

  // Create PerformanceEstimator
  if(perfModel != nullptr)
  {
    return new PerformanceEstimator(perfModel);
  }
  else
  {
    return nullptr;
  }
}

Backend* Factory::getTracePrinter(int var_)
{
  // Get variant specific printer
  Printer* printer;
  switch((var_t)var_)
  {
    	case CV32E40PXISAACV4:
		printer = new CV32E40PXISAACV4_Printer();
		break;
	case CV32E40PXISAACV34:
		printer = new CV32E40PXISAACV34_Printer();
		break;
	case CV32E40PXISAACV26:
		printer = new CV32E40PXISAACV26_Printer();
		break;
	case CV32E40PXISAACV8:
		printer = new CV32E40PXISAACV8_Printer();
		break;
	case CV32E40PXISAACV23:
		printer = new CV32E40PXISAACV23_Printer();
		break;
	case CV32E40PXISAACV5:
		printer = new CV32E40PXISAACV5_Printer();
		break;
	case InstructionTrace_RV64IM_Zicsr:
		printer = new InstructionTrace_RV64IM_Zicsr_Printer();
		break;
	case CV32E40PXISAACV39:
		printer = new CV32E40PXISAACV39_Printer();
		break;
	case InstructionTrace_RV32IM_Zicsr:
		printer = new InstructionTrace_RV32IM_Zicsr_Printer();
		break;
	case CV32E40PXISAACV35:
		printer = new CV32E40PXISAACV35_Printer();
		break;
	case CV32E40PXISAACV24:
		printer = new CV32E40PXISAACV24_Printer();
		break;
	case CV32E40PXISAACV20:
		printer = new CV32E40PXISAACV20_Printer();
		break;
	case CV32E40PXISAACV19:
		printer = new CV32E40PXISAACV19_Printer();
		break;
	case CV32E40PXISAACV18:
		printer = new CV32E40PXISAACV18_Printer();
		break;
	case CV32E40PXISAACV37:
		printer = new CV32E40PXISAACV37_Printer();
		break;
	case CV32E40PXISAACV31:
		printer = new CV32E40PXISAACV31_Printer();
		break;
	case CV32E40PXISAACV11:
		printer = new CV32E40PXISAACV11_Printer();
		break;
	case InstructionTrace_XISAAC:
		printer = new InstructionTrace_XISAAC_Printer();
		break;
	case CV32E40PXISAACV33:
		printer = new CV32E40PXISAACV33_Printer();
		break;
	case CV32E40PXISAACV38:
		printer = new CV32E40PXISAACV38_Printer();
		break;
	case CV32E40PXISAACV3:
		printer = new CV32E40PXISAACV3_Printer();
		break;
	case CV32E40PXISAACV14:
		printer = new CV32E40PXISAACV14_Printer();
		break;
	case CV32E40PXISAACV2:
		printer = new CV32E40PXISAACV2_Printer();
		break;
	case CV32E40PXISAACV43:
		printer = new CV32E40PXISAACV43_Printer();
		break;
	case CV32E40PXISAACV29:
		printer = new CV32E40PXISAACV29_Printer();
		break;
	case CV32E40PXISAACV6:
		printer = new CV32E40PXISAACV6_Printer();
		break;
	case CV32E40PXISAACV42:
		printer = new CV32E40PXISAACV42_Printer();
		break;
	case CV32E40PXISAACV7:
		printer = new CV32E40PXISAACV7_Printer();
		break;
	case CV32E40PXISAACV13:
		printer = new CV32E40PXISAACV13_Printer();
		break;
	case InstructionTrace_RV64IMF_Zicsr:
		printer = new InstructionTrace_RV64IMF_Zicsr_Printer();
		break;
	case CV32E40PXISAACV41:
		printer = new CV32E40PXISAACV41_Printer();
		break;
	case CV32E40PXISAACV15:
		printer = new CV32E40PXISAACV15_Printer();
		break;
	case CV32E40PXISAACV25:
		printer = new CV32E40PXISAACV25_Printer();
		break;
	case CV32E40PXISAACV36:
		printer = new CV32E40PXISAACV36_Printer();
		break;
	case CV32E40PXISAACV12:
		printer = new CV32E40PXISAACV12_Printer();
		break;
	case CVA6:
		printer = new CVA6_Printer();
		break;
	case CV32E40PXISAACV28:
		printer = new CV32E40PXISAACV28_Printer();
		break;
	case CV32E40PXISAACV32:
		printer = new CV32E40PXISAACV32_Printer();
		break;
	case CV32E40PXISAAC:
		printer = new CV32E40PXISAAC_Printer();
		break;
	case CV32E40PXISAACV10:
		printer = new CV32E40PXISAACV10_Printer();
		break;
	case CV32E40PXISAACV44:
		printer = new CV32E40PXISAACV44_Printer();
		break;
	case CV32E40PXISAACV0:
		printer = new CV32E40PXISAACV0_Printer();
		break;
	case CV32E40PXISAACV22:
		printer = new CV32E40PXISAACV22_Printer();
		break;
	case AssemblyTrace_RV64:
		printer = new AssemblyTrace_RV64_Printer();
		break;
	case CV32E40PXISAACV17:
		printer = new CV32E40PXISAACV17_Printer();
		break;
	case CV32E40PXISAACV1:
		printer = new CV32E40PXISAACV1_Printer();
		break;
	case CV32E40PXISAACV21:
		printer = new CV32E40PXISAACV21_Printer();
		break;
	case AssemblyTrace_RV32:
		printer = new AssemblyTrace_RV32_Printer();
		break;
	case CV32E40PXISAACV16:
		printer = new CV32E40PXISAACV16_Printer();
		break;
	case CVA6XISAAC:
		printer = new CVA6XISAAC_Printer();
		break;
	case CV32E40P:
		printer = new CV32E40P_Printer();
		break;
	case CV32E40PXISAACV30:
		printer = new CV32E40PXISAACV30_Printer();
		break;
	case CV32E40PXISAACV40:
		printer = new CV32E40PXISAACV40_Printer();
		break;
	case CV32E40PXISAACV9:
		printer = new CV32E40PXISAACV9_Printer();
		break;
	case CV32E40PXISAACV27:
		printer = new CV32E40PXISAACV27_Printer();
		break;

    default: printer = nullptr;
  }

  // Create TracePrinter
  if(printer != nullptr)
  {
    return new TracePrinter(printer);
  }
  else
  {
    return nullptr;
  }
}

} // namespace SwEvalBackends
