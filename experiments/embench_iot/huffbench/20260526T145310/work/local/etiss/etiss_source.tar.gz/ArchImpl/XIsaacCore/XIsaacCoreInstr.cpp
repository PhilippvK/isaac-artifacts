/**
 * Generated on Tue, 26 May 2026 15:07:18 +0200.
 *
 * This file contains the instruction behavior models of the default
 * instruction set for the XIsaacCore core architecture.
 */

#include "XIsaacCoreArch.h"
#include "XIsaacCoreFuncs.h"

using namespace etiss;
using namespace etiss::instr;

