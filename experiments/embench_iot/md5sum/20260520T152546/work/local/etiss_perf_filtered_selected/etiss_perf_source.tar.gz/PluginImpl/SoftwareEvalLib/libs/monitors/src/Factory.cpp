
/*
 * Copyright 2022 Chair of EDA, Technical University of Munich
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	 http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "Factory.h" 

#include "Monitor.h"

#include "InstructionTrace_RV64IM_Zicsr_Monitor.h"
#include "InstructionTrace_RV32IM_Zicsr_Monitor.h"
#include "InstructionTrace_XISAAC_Monitor.h"
#include "CV32E40PXISAACV2_Monitor.h"
#include "InstructionTrace_RV64IMF_Zicsr_Monitor.h"
#include "CVA6_Monitor.h"
#include "CV32E40PXISAAC_Monitor.h"
#include "CV32E40PXISAACV0_Monitor.h"
#include "AssemblyTrace_RV64_Monitor.h"
#include "CV32E40PXISAACV1_Monitor.h"
#include "AssemblyTrace_RV32_Monitor.h"
#include "CVA6XISAAC_Monitor.h"
#include "CV32E40P_Monitor.h"

namespace SwEvalMonitors
{

int Factory::getVariantHandle(std::string varName_)
{
    	if(varName_ == "InstructionTrace_RV64IM_Zicsr"){ return InstructionTrace_RV64IM_Zicsr; }
	if(varName_ == "InstructionTrace_RV32IM_Zicsr"){ return InstructionTrace_RV32IM_Zicsr; }
	if(varName_ == "InstructionTrace_XISAAC"){ return InstructionTrace_XISAAC; }
	if(varName_ == "CV32E40PXISAACV2"){ return CV32E40PXISAACV2; }
	if(varName_ == "InstructionTrace_RV64IMF_Zicsr"){ return InstructionTrace_RV64IMF_Zicsr; }
	if(varName_ == "CVA6"){ return CVA6; }
	if(varName_ == "CV32E40PXISAAC"){ return CV32E40PXISAAC; }
	if(varName_ == "CV32E40PXISAACV0"){ return CV32E40PXISAACV0; }
	if(varName_ == "AssemblyTrace_RV64"){ return AssemblyTrace_RV64; }
	if(varName_ == "CV32E40PXISAACV1"){ return CV32E40PXISAACV1; }
	if(varName_ == "AssemblyTrace_RV32"){ return AssemblyTrace_RV32; }
	if(varName_ == "CVA6XISAAC"){ return CVA6XISAAC; }
	if(varName_ == "CV32E40P"){ return CV32E40P; }

    return -1;
}

Monitor* Factory::getMonitor(int var_)
{
  switch((var_t)var_)
  {
    	case InstructionTrace_RV64IM_Zicsr: return new InstructionTrace_RV64IM_Zicsr_Monitor();
	case InstructionTrace_RV32IM_Zicsr: return new InstructionTrace_RV32IM_Zicsr_Monitor();
	case InstructionTrace_XISAAC: return new InstructionTrace_XISAAC_Monitor();
	case CV32E40PXISAACV2: return new CV32E40PXISAACV2_Monitor();
	case InstructionTrace_RV64IMF_Zicsr: return new InstructionTrace_RV64IMF_Zicsr_Monitor();
	case CVA6: return new CVA6_Monitor();
	case CV32E40PXISAAC: return new CV32E40PXISAAC_Monitor();
	case CV32E40PXISAACV0: return new CV32E40PXISAACV0_Monitor();
	case AssemblyTrace_RV64: return new AssemblyTrace_RV64_Monitor();
	case CV32E40PXISAACV1: return new CV32E40PXISAACV1_Monitor();
	case AssemblyTrace_RV32: return new AssemblyTrace_RV32_Monitor();
	case CVA6XISAAC: return new CVA6XISAAC_Monitor();
	case CV32E40P: return new CV32E40P_Monitor();
 
    default: return nullptr;
  }
}

} //namespace: SwEvalMonitors
