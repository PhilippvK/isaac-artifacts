
/*
 * Copyright 2022 Chair of EDA, Technical University of Munich
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	 http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef SWEVAL_BACKENDS_FACTORY_H
#define SWEVAL_BACKENDS_FACTORY_H

#include "Channel.h"
#include "Backend.h"

#include <string>

namespace SwEvalBackends
{

class Factory
{
private:
  enum var_t { 
	CV32E40PXISAACV4,
	CV32E40PXISAACV8,
	CV32E40PXISAACV23,
	CV32E40PXISAACV5,
	InstructionTrace_RV64IM_Zicsr,
	InstructionTrace_RV32IM_Zicsr,
	CV32E40PXISAACV24,
	CV32E40PXISAACV20,
	CV32E40PXISAACV19,
	CV32E40PXISAACV18,
	CV32E40PXISAACV11,
	InstructionTrace_XISAAC,
	CV32E40PXISAACV3,
	CV32E40PXISAACV14,
	CV32E40PXISAACV2,
	CV32E40PXISAACV6,
	CV32E40PXISAACV7,
	CV32E40PXISAACV13,
	InstructionTrace_RV64IMF_Zicsr,
	CV32E40PXISAACV15,
	CV32E40PXISAACV12,
	CVA6,
	CV32E40PXISAAC,
	CV32E40PXISAACV10,
	CV32E40PXISAACV0,
	CV32E40PXISAACV22,
	AssemblyTrace_RV64,
	CV32E40PXISAACV17,
	CV32E40PXISAACV1,
	CV32E40PXISAACV21,
	AssemblyTrace_RV32,
	CV32E40PXISAACV16,
	CVA6XISAAC,
	CV32E40P,
	CV32E40PXISAACV9 
  };
public:
  int getVariantHandle(std::string);
  Channel* getChannel(int);
  Backend* getPerformanceEstimator(int);
  Backend* getTracePrinter(int);
};

} // namespace SwEvalBackends

#endif //SWEVAL_BACKENDS_FACTORY_H
