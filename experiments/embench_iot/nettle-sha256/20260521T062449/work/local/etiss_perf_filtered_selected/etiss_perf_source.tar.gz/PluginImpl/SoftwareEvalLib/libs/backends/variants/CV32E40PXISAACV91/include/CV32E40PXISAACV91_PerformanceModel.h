/*
* Copyright 2026 Chair of EDA, Technical University of Munich
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*	 http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/********************* AUTO GENERATE FILE (create by M2-ISA-R-Perf) *********************/


#ifndef SWEVAL_BACKENDS_CV32E40PXISAACV91_PERFORMANCE_MODEL_H
#define SWEVAL_BACKENDS_CV32E40PXISAACV91_PERFORMANCE_MODEL_H

#include <stdbool.h>
#include <string>
#include <cstdint>

#include "PerformanceModel.h"
#include "Channel.h"

#include "models/common/StandardRegisterModel.h"
#include "models/common/StaticBranchPredictModel.h"
#include "models/cv32e40p/DividerModel.h"
#include "models/cv32e40p/DividerUnsignedModel.h"

namespace CV32E40PXISAACV91{

extern SchedulingFunctionSet* CV32E40PXISAACV91_SchedulingFunctionSet;

class CV32E40PXISAACV91_PerformanceModel : public PerformanceModel
{
public:

  CV32E40PXISAACV91_PerformanceModel() : PerformanceModel("CV32E40PXISAACV91", CV32E40PXISAACV91_SchedulingFunctionSet)
    ,regModel(this)
    ,staBranchPredModel(this)
    ,divider(this)
    ,divider_u(this)
  {};

  // Single-Element Timing Variables
  uint64_t IF_stage = 0;
  uint64_t ID_stage = 0;
  uint64_t EX_stage = 0;
  uint64_t EX_substage_CUSTOM2_I = 0;
  uint64_t EX_substage_CUSTOM2_X = 0;
  uint64_t EX_substage_CUSTOM2_O = 0;
  uint64_t EX_substage_CUSTOM5_I = 0;
  uint64_t EX_substage_CUSTOM5_X = 0;
  uint64_t EX_substage_CUSTOM5_O = 0;
  uint64_t EX_substage_CUSTOM9_I = 0;
  uint64_t EX_substage_CUSTOM9_X = 0;
  uint64_t EX_substage_CUSTOM9_O = 0;
  uint64_t EX_substage_CUSTOM21_I = 0;
  uint64_t EX_substage_CUSTOM21_X = 0;
  uint64_t EX_substage_CUSTOM21_O = 0;
  uint64_t EX_substage_CUSTOM27_I = 0;
  uint64_t EX_substage_CUSTOM27_X = 0;
  uint64_t EX_substage_CUSTOM27_O = 0;
  uint64_t EX_substage_CUSTOM29_I = 0;
  uint64_t EX_substage_CUSTOM29_X = 0;
  uint64_t EX_substage_CUSTOM29_O = 0;
  uint64_t EX_substage_CUSTOM31_I = 0;
  uint64_t EX_substage_CUSTOM31_X = 0;
  uint64_t EX_substage_CUSTOM31_O = 0;
  uint64_t EX_substage_CUSTOM33_I = 0;
  uint64_t EX_substage_CUSTOM33_X = 0;
  uint64_t EX_substage_CUSTOM33_O = 0;
  uint64_t EX_substage_CUSTOM35_I = 0;
  uint64_t EX_substage_CUSTOM35_X = 0;
  uint64_t EX_substage_CUSTOM35_O = 0;
  uint64_t EX_substage_CUSTOM37_I = 0;
  uint64_t EX_substage_CUSTOM37_X = 0;
  uint64_t EX_substage_CUSTOM37_O = 0;
  uint64_t WB_stage = 0;


  // External Resource Models
  common::StandardRegisterModel regModel;
  common::StaticBranchPredictModel staBranchPredModel;
  cv32e40p::DividerModel divider;
  cv32e40p::DividerUnsignedModel divider_u;

  virtual void connectChannel(Channel*);
  virtual uint64_t getCycleCount(void);
  virtual std::string getPipelineStream(void);
  virtual std::string getPrintHeader(void);

};

} // namespace CV32E40PXISAACV91

#endif // SWEVAL_BACKENDS_CV32E40PXISAACV91_PERFORMANCE_MODEL_H