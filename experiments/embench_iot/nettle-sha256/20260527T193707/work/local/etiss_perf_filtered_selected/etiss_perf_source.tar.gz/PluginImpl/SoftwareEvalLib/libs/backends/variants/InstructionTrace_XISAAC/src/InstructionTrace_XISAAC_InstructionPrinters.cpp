/*
* Copyright 2026 Chair of EDA, Technical University of Munich
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*	 http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/********************* AUTO GENERATE FILE (create by M2-ISA-R::Trace-Generator) *********************/


#include "Printer.h"
#include "Channel.h"

#include "InstructionTrace_XISAAC_Printer.h"

#include <sstream>
#include <string>
#include <iomanip>

InstructionPrinterSet *InstructionTrace_XISAAC_InstrPrinterSet = new InstructionPrinterSet("InstructionTrace_XISAAC_InstrPrinterSet");

static InstructionPrinter *instrPrinter_Reg_Reg_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "Reg_Reg_Type",
  0,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM1_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM1_Type",
  1,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM2_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM2_Type",
  2,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM7_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM7_Type",
  3,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM23_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM23_Type",
  4,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_uimm5() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM25_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM25_Type",
  5,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM27_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM27_Type",
  6,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM32_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM32_Type",
  7,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM33_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM33_Type",
  8,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM38_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM38_Type",
  9,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CUSTOM41_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CUSTOM41_Type",
  10,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_Reg_Imm_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "Reg_Imm_Type",
  11,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_imm() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_Load_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "Load_Type",
  12,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_imm() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_mem_addr() << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_Store_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "Store_Type",
  13,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_imm() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_mem_addr() << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CSR_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CSR_Type",
  14,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_csr() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_csr_reg() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_CSR_Imm_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "CSR_Imm_Type",
  15,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_imm() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_csr() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_Branch_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "Branch_Type",
  16,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_imm() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs2_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_jump_pc() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_RegLoad_U_Type = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "RegLoad_U_Type",
  17,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_imm() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter__DEF = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "_DEF",
  18,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_JAL = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "JAL",
  19,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_imm() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_jump_pc() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
static InstructionPrinter *instrPrinter_JALR = new InstructionPrinter(
  InstructionTrace_XISAAC_InstrPrinterSet,
  "JALR",
  20,
  [](Printer* printer_){
    std::stringstream ret_strs;
    InstructionTrace_XISAAC_Printer* printer = static_cast<InstructionTrace_XISAAC_Printer*>(printer_);
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_pc() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_code() << " , ";
    ret_strs << std::setfill(' ') << std::setw(50) << std::left << printer->get_assembly() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_imm() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rs1_data() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_rd_data() << " , ";
    ret_strs << "0x" << std::setfill('0') << std::setw(16) << std::right << std::hex << printer->get_jump_pc() << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::setfill('-') << std::setw(18) << "" << " , ";
    ret_strs << std::endl;
    return ret_strs.str();
  }
);
