/*
* Copyright 2026 Chair of EDA, Technical University of Munich
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*	 http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/********************* AUTO GENERATE FILE (create by M2-ISA-R-Perf) *********************/


#ifndef SWEVAL_BACKENDS_CV32E40PXISAACV34_PERFORMANCE_MODEL_H
#define SWEVAL_BACKENDS_CV32E40PXISAACV34_PERFORMANCE_MODEL_H

#include <stdbool.h>
#include <string>
#include <cstdint>

#include "PerformanceModel.h"
#include "Channel.h"

#include "models/common/StandardRegisterModel.h"
#include "models/common/StaticBranchPredictModel.h"
#include "models/cv32e40p/DividerModel.h"
#include "models/cv32e40p/DividerUnsignedModel.h"

namespace CV32E40PXISAACV34{

extern SchedulingFunctionSet* CV32E40PXISAACV34_SchedulingFunctionSet;

class CV32E40PXISAACV34_PerformanceModel : public PerformanceModel
{
public:

  CV32E40PXISAACV34_PerformanceModel() : PerformanceModel("CV32E40PXISAACV34", CV32E40PXISAACV34_SchedulingFunctionSet)
    ,regModel(this)
    ,staBranchPredModel(this)
    ,divider(this)
    ,divider_u(this)
  {};

  // Single-Element Timing Variables
  uint64_t IF_stage = 0;
  uint64_t ID_stage = 0;
  uint64_t EX_stage = 0;
  uint64_t EX_substage_CUSTOM2_I = 0;
  uint64_t EX_substage_CUSTOM2_X = 0;
  uint64_t EX_substage_CUSTOM2_O = 0;
  uint64_t EX_substage_CUSTOM8_I = 0;
  uint64_t EX_substage_CUSTOM8_X = 0;
  uint64_t EX_substage_CUSTOM8_O = 0;
  uint64_t EX_substage_CUSTOM17_I = 0;
  uint64_t EX_substage_CUSTOM17_X = 0;
  uint64_t EX_substage_CUSTOM17_O = 0;
  uint64_t EX_substage_CUSTOM24_I = 0;
  uint64_t EX_substage_CUSTOM24_X = 0;
  uint64_t EX_substage_CUSTOM24_O = 0;
  uint64_t EX_substage_CUSTOM26_I = 0;
  uint64_t EX_substage_CUSTOM26_X = 0;
  uint64_t EX_substage_CUSTOM26_O = 0;
  uint64_t EX_substage_CUSTOM28_I = 0;
  uint64_t EX_substage_CUSTOM28_X = 0;
  uint64_t EX_substage_CUSTOM28_O = 0;
  uint64_t WB_stage = 0;


  // External Resource Models
  common::StandardRegisterModel regModel;
  common::StaticBranchPredictModel staBranchPredModel;
  cv32e40p::DividerModel divider;
  cv32e40p::DividerUnsignedModel divider_u;

  virtual void connectChannel(Channel*);
  virtual uint64_t getCycleCount(void);
  virtual std::string getPipelineStream(void);
  virtual std::string getPrintHeader(void);

};

} // namespace CV32E40PXISAACV34

#endif // SWEVAL_BACKENDS_CV32E40PXISAACV34_PERFORMANCE_MODEL_H