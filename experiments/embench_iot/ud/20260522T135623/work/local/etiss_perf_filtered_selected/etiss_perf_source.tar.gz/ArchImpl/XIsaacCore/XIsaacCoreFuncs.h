/**
 * Generated on Fri, 22 May 2026 14:18:46 +0200.
 *
 * This file contains the function prototypes for the XIsaacCore core architecture.
 */

#ifndef __XISAACCORE_FUNCS_H
#define __XISAACCORE_FUNCS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "XIsaacCore.h"
#include "etiss/jit/CPU.h"
#include "etiss/jit/System.h"
#include "etiss/jit/ReturnCode.h"
// #include "etiss/jit/Coverage.h"

void leave(etiss_int32 priv_lvl);

void wait(etiss_int32 flag);

etiss_uint8 XIsaacCore_extension_enabled(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers, etiss_int8 extension);

etiss_uint64 etiss_get_cycles(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers);

etiss_uint64 etiss_get_time();

etiss_uint64 etiss_get_instret(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers);

etiss_uint32 XIsaacCore_sstatus_mask(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers);

etiss_uint32 XIsaacCore_mstatus_mask(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers);

etiss_uint32 XIsaacCore_csr_read(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers, etiss_uint32 csr);

void XIsaacCore_csr_write(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers, etiss_uint32 csr, etiss_uint32 val);

etiss_uint8 etiss_semihost_enabled();

etiss_int64 etiss_semihost(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers, etiss_uint32 XLEN, etiss_uint64 operation, etiss_uint64 parameter);

etiss_uint64 XIsaacCore_get_field(etiss_uint64 reg, etiss_uint64 mask);

etiss_uint64 XIsaacCore_set_field(etiss_uint64 reg, etiss_uint64 mask, etiss_uint64 val);

etiss_uint8 XIsaacCore_ctz(etiss_uint64 val);

void XIsaacCore_raise(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers, etiss_int32 irq, etiss_uint32 mcause);

void XIsaacCore_translate_exc_code(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers, etiss_int32 cause);

etiss_uint32 XIsaacCore_calc_irq_mcause(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers);

void XIsaacCore_check_irq(ETISS_CPU * const cpu, ETISS_System * const system, void * const * const plugin_pointers);

#ifdef __cplusplus
}
#endif

#endif