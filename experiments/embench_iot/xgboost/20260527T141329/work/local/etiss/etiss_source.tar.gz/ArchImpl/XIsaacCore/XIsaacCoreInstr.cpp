/**
 * Generated on Wed, 27 May 2026 14:23:20 +0200.
 *
 * This file contains the instruction behavior models of the default
 * instruction set for the XIsaacCore core architecture.
 */

#include "XIsaacCoreArch.h"
#include "XIsaacCoreFuncs.h"

using namespace etiss;
using namespace etiss::instr;

